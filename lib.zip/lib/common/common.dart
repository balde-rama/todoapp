import 'package:flutter/cupertino.dart';
const regularFont= "Roboyo-Regular";
const boldFont= "Roboto-Bold";

Color primaryBackground =const Color(0xFF0A155A);
const secondBackground= Color(0xFF3D47AF);
const secondColor= Color(0xff4f74ff);
const thirdFondColor= Color(0xffbbc208);
const businessIndicator= Color(0xffd103fc);
const personalIndicator= Color(0xff4f74ff);
Color globalWhite =const Color(0xffffffff).withOpacity(.8);
